#include "Course.h"
#include <algorithm>
#include <sstream>

// Default constructor
Course::Course() : id(0), credits(0) {}

// Parameterized constructor with validation
Course::Course(int id, const std::string& name, int credits, 
               const std::string& moedA, const std::string& moedB, 
               const std::string& lecturer)
    : id(id), name(name), credits(credits), moedA(moedA), moedB(moedB), lecturer(lecturer) {
    validateId(id);//Purpose: Validates that the course ID is a positive integer.

    validateCredits(credits);
    validateName(name);
}

//Purpose: Validates that the course ID is a positive integer.
// Validation helper methods
void Course::validateId(int courseId) const {
    if (courseId <= 0) {
        throw std::invalid_argument("Course ID must be positive");
    }
}
//Purpose: Validates that course credits are within a reasonable academic range.

void Course::validateCredits(int courseCredits) const {
    if (courseCredits < 0 || courseCredits > 20) {
        throw std::invalid_argument("Course credits must be between 0 and 20");
    }
}
//Purpose: Validates that the course name is not empty and not excessively long.

void Course::validateName(const std::string& courseName) const {
    if (courseName.empty() || courseName.length() > 100) {
        throw std::invalid_argument("Course name cannot be empty or longer than 100 characters");
    }
}

// Const getters with noexcept guarantee
int Course::getId() const noexcept {
    return id;
}

const std::string& Course::getName() const noexcept {
    return name;
}

int Course::getCredits() const noexcept {
    return credits;
}

const std::string& Course::getMoedA() const noexcept {
    return moedA;
}

const std::string& Course::getMoedB() const noexcept {
    return moedB;
}

const std::string& Course::getLecturer() const noexcept {
    return lecturer;
}

// Setters with validation
void Course::setName(const std::string& newName) {
    validateName(newName);
    name = newName;
}

void Course::setCredits(int newCredits) {
    validateCredits(newCredits);
    credits = newCredits;
}

void Course::setMoedA(const std::string& date) {
    moedA = date; // Could add date format validation here
}

void Course::setMoedB(const std::string& date) {
    moedB = date; // Could add date format validation here
}

void Course::setLecturer(const std::string& name) {
    if (name.length() > 100) {
        throw std::invalid_argument("Lecturer name too long");
    }
    lecturer = name;
}

// Utility methods
// // This function promises it will never throw an exception outside
// of the validation methods, making it safe to call in noexcept contexts.
bool Course::isValid() const noexcept {
    try {
        validateId(id);
        validateCredits(credits);
        validateName(name);
        return true;
    } catch (...) {
        return false;
    }
}

std::string Course::toString() const {
    std::ostringstream oss;
    oss << "Course{ID: " << id << ", Name: '" << name 
        << "', Credits: " << credits << ", Lecturer: '" << lecturer << "'}";
    return oss.str();
}

// Comparison operators
bool Course::operator==(const Course& other) const noexcept {
    return id == other.id;
}

bool Course::operator!=(const Course& other) const noexcept {
    return !(*this == other);
}

bool Course::operator<(const Course& other) const noexcept {
    return id < other.id;
}

// Stream output operator
std::ostream& operator<<(std::ostream& os, const Course& course) {
    os << "Course ID: " << course.id
       << ", Name: " << course.name
       << ", Credits: " << course.credits
       << ", Moed A: " << course.moedA
       << ", Moed B: " << course.moedB
       << ", Lecturer: " << course.lecturer;
    return os;
}

